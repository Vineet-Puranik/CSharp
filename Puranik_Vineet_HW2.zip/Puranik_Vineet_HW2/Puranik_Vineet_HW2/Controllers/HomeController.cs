﻿//Author: Vineet Puranik
//Date: February 14th, 2025
//Assignment: Homework 2
using Microsoft.AspNetCore.Mvc;
using System;
using Puranik_Vineet_HW2.Models;

namespace Puranik_Vineet_HW2.Controllers
{
    public class HomeController : Controller
    {
        //Directs to main page
        public IActionResult Index()
        {
            return View();
        }
        //Checks out Standard
        public IActionResult CheckoutStandard()
        {
            return View();
        }

        //View of Totals and calls methods from Standard Order
        [HttpPost]
        public IActionResult StandardTotals(StandardOrder standardOrder)
        {
            if (!ModelState.IsValid)
            {
                return View("CheckoutStandard", standardOrder);
            }

            standardOrder.CustomerType = CustomerType.Standard;
            standardOrder.CalcSubtotals(); 

            return View("StandardTotals", standardOrder);
        }
        //Checks out Event
        public IActionResult CheckoutEvent()
        {
            return View();
        }

        //View of Totals and calls methods from Event Order
        [HttpPost]
        public IActionResult EventTotals(EventOrder eventOrder)
        {
            if (!ModelState.IsValid)
            {
                return View("CheckoutEvent", eventOrder);
            }

            eventOrder.CustomerType = CustomerType.Event;
            eventOrder.CalcTotals();

            return View("EventTotals", eventOrder);
        }
    }
}
