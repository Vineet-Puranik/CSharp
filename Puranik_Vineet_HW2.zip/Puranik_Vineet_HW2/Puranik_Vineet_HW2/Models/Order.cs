﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Puranik_Vineet_HW2.Models
{
    //Enum class for Customer Type
    public enum CustomerType
    {
        Standard,
        Event
    }

    public abstract class Order
    {
        //Constants for price of adult and child tickets
        public const decimal ADULT_PRICE = 11m;
        public const decimal CHILD_PRICE = 6m;

        [Display(Name = "Number of Adult Tickets")]
        public int NumberOfAdultTickets { get; set; }

        [Display(Name = "Number of Child Tickets")]
        public int NumberOfChildTickets { get; set; }

        [Display(Name = "Total Number of Tickets")]
        public int TotalItems => NumberOfAdultTickets + NumberOfChildTickets;

        [Display(Name = "Adult Tickets Subtotal")]
        public decimal AdultSubtotal => NumberOfAdultTickets * ADULT_PRICE;

        [Display(Name = "Child Ticket Subtotal")]
        public decimal ChildSubtotal => NumberOfChildTickets * CHILD_PRICE;

        public decimal Subtotal => AdultSubtotal + ChildSubtotal;

        public decimal Total { get; protected set; }

        [Display(Name = "Customer Type")]
        public CustomerType CustomerType { get; set; }

        public virtual void CalcTotals()
        {   
            Total = Subtotal; 
        }

        public virtual void CalcSubtotals()
        {
            
        }
    }
}
