﻿using System.ComponentModel.DataAnnotations;

namespace Puranik_Vineet_HW2.Models
{
    //Inherits from Order
    public class EventOrder : Order
    {
        //Annotations and Requirements for Customer Code
        [Required(ErrorMessage = "Customer code is required.")]
        [Display(Name = "Customer Code")]
        [RegularExpression(@"^[A-Za-z]{3,5}$", ErrorMessage = "Customer code must be 3 to 5 letters.")]
        public string CustomerCode { get; set; } = string.Empty;

        //Annotations and Requirements for Service Fee
        [Display(Name = "Service Fee")]
        [Range(0, 175, ErrorMessage = "Service fee must be between 0 and 175.")]
        public decimal ServiceFee { get; set; }

        //Setting up the Preferred Customwr Question
        [Display(Name = "Is this customer a Preferred Customer?")]
        public bool PreferredCustomer { get; set; }

        public override void CalcSubtotals()
        {
            base.CalcSubtotals();
        }

        //Allows the total to reflect the addition of a Service Fee
        public override void CalcTotals()
        {
            CalcSubtotals();
            ServiceFee = PreferredCustomer ? 0m : ServiceFee;
            Total = Subtotal + ServiceFee;
        }
    }
}