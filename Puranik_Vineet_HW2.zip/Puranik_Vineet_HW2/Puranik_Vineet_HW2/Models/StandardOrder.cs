﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Puranik_Vineet_HW2.Models
{
    //Inherits from Order
    public class StandardOrder : Order
    {
        //Creates a constant for Sales Tax
        private const decimal SALES_TAX_RATE = 0.0875m;

        //Annotation for Customer Name
        [Required(ErrorMessage = "Customer name is required.")]
        [Display(Name = "Customer Name")]
        public string? CustomerName { get; set; }

        [Display(Name = "Sales Tax")]
        public decimal SalesTax => Subtotal * SALES_TAX_RATE;

        //Calculates Total that Reflects the addition of the subtotal
        public override void CalcSubtotals()
        {
            base.CalcSubtotals();
            Total = Subtotal + SalesTax;
        }
    }
}
